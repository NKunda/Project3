$(document).ready(function(){

//Function to display alert and disable buy button
    $(".cartItems").click(function(){
    	alert("This item has been added to your cart");
        $(this).attr('disabled','disabled');
    });


//Function to prompt to go to checkout and stops if user doesn't want to
	$("#checkout").click(function(e){
    	var r = confirm("Do you really want to proceed to checkout ??");
	    if (r == true) {
	        window.location.href="form.html";
	    }   
	});


});

