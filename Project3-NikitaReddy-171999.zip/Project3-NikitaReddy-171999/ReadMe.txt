Men.html, Kid.html and women.html are changed and 2 new js files are added:


CHANGES:
Men.html, Kid.html and women.html are updated with checkout button. 
Once user clicks on the buy button after selecting the size and color if throws an alert message: The item had been added to cart, by addig the items to the Cart.
When user clicks on the checkout button it throws a alert message: Do you really want to proceed to checkout??, if yes it takes you to the billing page, if not it user can continue to shop a different item.

